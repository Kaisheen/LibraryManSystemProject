package ClassImplemantation;

import Panel.LoginPage;

public class Application {
    
    public static void main(String[] args) {
        
        new LoginPage().setVisible(true);
    }
    
}
